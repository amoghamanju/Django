from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import User, Movie, Checkout


def home(request):
    return render(request, 'rental/home.html')


def account_creation(request):
    if request.method == 'POST':
        # Handle account creation logic here
        pass
    return render(request, 'rental/account_creation.html')


def manage_movies(request):
    # Handle movie management logic here
    return render(request, 'rental/manage_movies.html')


def rent_return_movies(request):
    # Handle rent/return logic here
    return render(request, 'rental/rent_return.html')


# AJAX views for dbUser, dbMovie, dbRent
