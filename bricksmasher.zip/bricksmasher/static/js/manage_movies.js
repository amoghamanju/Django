// Static files directory: static/js/manage_movies.js

function fetchMovies() {
    fetch('/dbMovie/')
        .then(response => response.json())
        .then(data => {
            const movies = data.movies;
            const tableBody = document.getElementById('movie-list');
            tableBody.innerHTML = '';  // Clear existing rows
            movies.forEach(movie => {
                const row = `<tr>
                    <td>${movie.title}</td>
                    <td>${movie.in_stock}</td>
                    <td>${movie.checked_out}</td>
                    <td><button onclick="updateStock(${movie.id}, 'add')">+</button></td>
                    <td><button onclick="updateStock(${movie.id}, 'remove')">-</button></td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        });
}

function addNewMovie() {
    const title = document.getElementById('new-movie-title').value;
    fetch('/dbMovie/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken  // Ensure CSRF token is available globally
        },
        body: JSON.stringify({ action: 'new', title: title })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            document.getElementById('movie-message').innerText = data.error;
        } else {
            fetchMovies();  // Refresh the list
            document.getElementById('new-movie-title').value = '';  // Clear input
        }
    });
}

function updateStock(movieId, action) {
    fetch('/dbMovie/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken  // Ensure CSRF token is available globally
        },
        body: JSON.stringify({ id: movieId, action: action })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error updating stock: ' + data.error);
        } else {
            fetchMovies();  // Refresh the list
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    fetchMovies();  // Initial fetch of movies
});
