from django.apps import AppConfig


class BricksmasherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bricksmasher'
