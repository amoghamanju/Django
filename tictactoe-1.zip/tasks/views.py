from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# Initialize or reset the game state
game_state = {
    'grid': {
        f'g{r}{c}': ''
        for r in range(3)
        for c in range(3)
    },
    'turn': 'X',
    'status': 'P'  # P for in progress, X for X won, O for O won, D for draw
}


def home(request):
  return render(request, 'home.html')


def check_win(grid):
  # Check rows, columns, and diagonals for a win condition
  lines = [[grid['g00'], grid['g01'], grid['g02']],
           [grid['g10'], grid['g11'], grid['g12']],
           [grid['g20'], grid['g21'], grid['g22']],
           [grid['g00'], grid['g10'], grid['g20']],
           [grid['g01'], grid['g11'], grid['g21']],
           [grid['g02'], grid['g12'], grid['g22']],
           [grid['g00'], grid['g11'], grid['g22']],
           [grid['g02'], grid['g11'], grid['g20']]]
  for line in lines:
    if line[0] == line[1] == line[2] and line[0] != '':
      return line[0]  # Return 'X' or 'O'
  return None


def tic_tac_toe(request, player):
  global game_state
  return render(request, 'tic_tac_toe.html', {'player': player})


@csrf_exempt
def game(request):
  global game_state
  if request.method == 'POST':
    data = json.loads(request.body)
    move = data.get('move')
    if move:
      row, col = move
      cell = f'g{row}{col}'
      if game_state['grid'][cell] == '' and game_state['status'] == 'P':
        game_state['grid'][cell] = game_state['turn']
        winner = check_win(game_state['grid'])
        if winner:
          game_state['status'] = winner  # Update status to 'X' or 'O'
        else:
          game_state['turn'] = 'O' if game_state['turn'] == 'X' else 'X'
          if all(value != '' for value in game_state['grid'].values()):
            game_state['status'] = 'D'  # Draw
  return JsonResponse(game_state)


def reset_game(request):
  # Reset the game to initial state
  global game_state
  game_state = {
      'grid': {
          f'g{r}{c}': ''
          for r in range(3)
          for c in range(3)
      },
      'turn': 'X',
      'status': 'P'
  }
  return JsonResponse(game_state)
