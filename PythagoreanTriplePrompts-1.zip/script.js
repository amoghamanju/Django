"use strict";
var values = [];

function validateAndPrompt(message) {
  var input;
  do {
    input = prompt(message);
  } while (isNaN(input) || parseInt(input) < 0);
  return parseInt(input);
}

values[0] = validateAndPrompt("Enter 1st number");
values[1] = validateAndPrompt("Enter 2nd number");
values[2] = validateAndPrompt("Enter 3rd number");

if (!isNaN(values[0]) && !isNaN(values[1]) && !isNaN(values[2])) {
  values[0] = Math.pow(values[0], 2);
  values[1] = Math.pow(values[1], 2);
  values[2] = Math.pow(values[2], 2);

  if (
    values[0] == values[1] + values[2] ||
    values[1] == values[0] + values[2] ||
    values[2] == values[0] + values[1]
  ) {
    $("#answer").html("YES! Pythagorean triple.").css({
      "font-weight": "bold",
      color: "green",
    });
  } else {
    $("#answer").html("NO. Not Pythagorean triple.").css({
      "font-style": "italic",
      color: "orange",
    });
  }
} else {
  $("#answer").html("ERROR");
}
