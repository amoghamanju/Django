$(document).ready(function() {
  $("#createButton").click(function() {
    createRectangle();
  });

  $("#displayArea").on("click", ".rectangle", function() {
    $(this).remove();
    event.stopPropagation();
  });
});

function createRectangle() {

  var top = $("#top").val();
  var left = $("#left").val();
  var red = $("#red").val();
  var green = $("#green").val();
  var blue = $("#blue").val();
  var height = $("#height").val();
  var width = $("#width").val();

  
  if (!isValidInput(top, left, red, green, blue, height, width)) {
    $("#errorMessage").text("Invalid input. Please check the values.");
    return;
  }


  $("#errorMessage").text("");


  var rectangle = $("<div></div>")
    .addClass("rectangle")
    .css({
      top: top + "px",
      left: left + "px",
      width: width + "px",
      height: height + "px",
      backgroundColor: `rgb(${red}, ${green}, ${blue})`,
    });

 
  $("#displayArea").append(rectangle);


  $("form")[0].reset();
}

function isValidInput(top, left, red, green, blue, height, width) {
 
  return !isNaN(top) && !isNaN(left) && !isNaN(red) && !isNaN(green) && !isNaN(blue) &&
    !isNaN(height) && !isNaN
