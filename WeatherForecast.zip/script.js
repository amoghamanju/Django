$(document).ready(function() {
  $('#weatherForm').submit(function(event) {
    event.preventDefault();
    $('#forecast').empty(); // Clear previous forecast

    var inputType = $('input[name=inputType]:checked').val();
    var location = $('#location').val();

    // Construct API URL based on input type
    var apiUrl = 'https://api.openweathermap.org/data/2.5/forecast';
    var apiKey = '0e984b84e75df704d7fb4935b7c3c5cb'; // Replace with your OpenWeather API key
    var params = '';

    if (inputType === 'city') {
      params = 'q=' + encodeURIComponent(location);
    } else if (inputType === 'zip') {
      params = 'zip=' + encodeURIComponent(location);
    } else if (inputType === 'coordinates') {
      var coordinates = location.split(',');
      if (coordinates.length === 2) {
        params = 'lat=' + encodeURIComponent(coordinates[0]) +
          '&lon=' + encodeURIComponent(coordinates[1]);
      } else {
        // Display error message if coordinates are not provided correctly
        $('#forecast').html('<p id="error">Invalid coordinates.</p>');
        return; // Stop execution
      }
    }

    apiUrl += '?' + params + '&appid=' + apiKey;

    // Make AJAX request to OpenWeather API
    $.getJSON(apiUrl)
      .done(function(data) {
        // Log API response
        console.log(data);

        // Process forecast data and display on UI
        displayForecast(data);
      })
      .fail(function() {
        // Display error message if API request fails
        $('#forecast').html('<p id="error">Invalid location or API error.</p>');
      });
  });
});

function displayForecast(data) {
  var forecastData = filterForecast(data);

  // Display forecast for next 3 days
  for (var day of forecastData) {
    var date = new Date(day.date * 1000); // Convert Unix timestamp to JavaScript date
    var temp = day.temp.toFixed(1); // Format temperature with 1 decimal place
    var cloudCover = day.cloudCover.toFixed(1); // Format cloud cover with 1 decimal place

    // Append forecast data to forecast div
    $('#forecast').append('<div class="forecast-info">' +
      '<h3>' + date.toDateString() + '</h3>' +
      '<p>Temperature: ' + temp + '°C</p>' +
      '<p>Cloud Cover: ' + cloudCover + '%</p>' +
      '</div>');
  }
}

function filterForecast(data) {
  var forecastData = [];

  // Filter forecast for next 3 days (excluding today)
  var currentDate = new Date();
  currentDate.setHours(0, 0, 0, 0); // Set time to midnight

  for (var forecast of data.list) {
    var forecastDate = new Date(forecast.dt * 1000);
    if (forecastDate > currentDate && forecastData.length < 3) {
      var date = forecastDate.getDate();
      var existingDay = forecastData.find(day => day.date === date);

      if (!existingDay) {
        forecastData.push({
          date: date,
          temp: forecast.main.temp_max - 273.15, // Convert temperature from Kelvin to Celsius
          cloudCover: forecast.clouds.all,
          pressure: forecast.main.pressure
        });
      } else {
        // Update max temperature, average cloud cover, and max pressure for the day
        existingDay.temp = Math.max(existingDay.temp, forecast.main.temp_max - 273.15);
        existingDay.cloudCover = (existingDay.cloudCover + forecast.clouds.all) / 2;
        existingDay.pressure = Math.max(existingDay.pressure, forecast.main.pressure);
      }
    }
  }
  return forecastData;
}
