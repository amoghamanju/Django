from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import User, Movie, Checkout
from django.http import HttpResponse
from django.views.generic import View
from django.contrib import messages
import json
from django.views.decorators.csrf import csrf_exempt
import logging
from django.views.decorators.http import require_POST


class ItemHandler(View):

    def get(self, request, *args, **kwargs):
        return HttpResponse('Item Handler GET response')

    def post(self, request, *args, **kwargs):
        return HttpResponse('Item Handler POST response')


def home(request):
    return render(request, 'home.html', {})


def account_creation(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')

        # Check if email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email address already in use.')
        else:
            # Create new user
            User.objects.create(first_name=first_name,
                                last_name=last_name,
                                email=email)
            messages.success(request, 'Account created successfully!')

        return redirect('account_creation')

    return render(request, 'account_creation.html')


def manage_movies(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        if title.strip():  # Ensuring the title is not just whitespace
            movie, created = Movie.objects.get_or_create(title=title)
            if created:
                movie.in_stock = 1  # Start with one copy in stock
                movie.save()
                message = f'Added new movie: {title}'
            else:
                message = 'Movie already exists!'
        else:
            message = 'Invalid movie title!'

    movies = Movie.objects.order_by('title')
    return render(request, 'manage_movies.html', {
        'movies': movies,
        'message': message if 'message' in locals() else ''
    })


def update_movie_stock(request):
    if request.method == 'POST' and request.is_ajax():
        data = json.loads(request.body)
        movie_id = data.get('movieId')
        action = data.get('action')

        try:
            movie = Movie.objects.get(id=movie_id)
            if action == 'add':
                movie.in_stock += 1
            elif action == 'remove' and movie.in_stock > 0:
                movie.in_stock -= 1
            movie.save()
            return JsonResponse({'success': True, 'new_stock': movie.in_stock})
        except Movie.DoesNotExist:
            return JsonResponse({'error': 'Movie not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request'}, status=400)


logger = logging.getLogger(__name__)


def rent_return(request):
    try:
        logger.debug("Received a request with method: %s", request.method)
        if request.method == 'POST':
            logger.debug("Request body: %s", request.body)
            data = json.loads(request.body)
            email = data.get('email')
            logger.debug("Email extracted: %s", email)

            if not email:
                return JsonResponse({'error': 'Email is required.'},
                                    status=400)

            user = User.objects.filter(email=email).first()
            if not user:
                return JsonResponse({'error': 'User not found.'}, status=404)

            checked_out_movies = Checkout.objects.filter(user=user)
            all_movies = Movie.objects.exclude(
                id__in=checked_out_movies.values_list('movie__id', flat=True))

            response_data = {
                'user': {
                    'first_name':
                    user.first_name,
                    'last_name':
                    user.last_name,
                    'checked_out_movies':
                    list(checked_out_movies.values('movie__title', 'id')),
                    'all_movies':
                    list(all_movies.values('title', 'id', 'in_stock'))
                }
            }
            return JsonResponse(response_data)

    except json.JSONDecodeError:
        logger.error("JSON Decode Error", exc_info=True)
        return JsonResponse({'error': 'Invalid JSON.'}, status=400)
    except Exception as e:
        logger.error("Unexpected error", exc_info=True)
        return JsonResponse({'error': str(e)}, status=500)


def checkout_movie(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        movie = Movie.objects.get(id=data['movieId'])
        user = User.objects.get(id=data['userId'])
        if movie.in_stock > 0:
            Checkout.objects.create(movie=movie, user=user)
            movie.in_stock -= 1
            movie.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse(
                {
                    'success': False,
                    'error': 'No stock available'
                }, status=400)
    return JsonResponse({'error': 'Invalid request'}, status=400)


@require_POST
def return_movie(request):
    try:
        data = json.loads(request.body)
        movie_id = data.get('movieId')

        if not movie_id:
            return JsonResponse({'error': 'Movie ID is required'}, status=400)

        checkout = Checkout.objects.filter(movie_id=movie_id).last()
        if checkout:
            checkout.movie.in_stock += 1
            checkout.movie.save()
            checkout.delete()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'error': 'No such checkout found'}, status=404)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
