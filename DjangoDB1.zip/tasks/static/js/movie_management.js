// Utility function to get CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            let cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Function to handle movie checkout
function checkoutMovie(movieId, userId) {
    fetch('/checkout_movie/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({movieId: movieId, userId: userId})
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok. Status: ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert('Movie checked out successfully!');
            location.reload(); // Reload to update the list
        } else {
            alert('Failed to checkout movie: ' + data.error);
        }
    })
    .catch(error => alert('Error: ' + error));
}

// Function to handle movie return
// Function to handle movie return
function returnMovie(movieId) {
    const csrftoken = getCookie('csrftoken');  // Ensure CSRF token is being used

    fetch('/return_movie/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken
        },
        body: JSON.stringify({movieId: movieId})  // Ensure this is the expected key in Python
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to return movie. Status: ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert('Movie returned successfully!');
            location.reload(); // Reload to update the list
        } else {
            alert('Failed to return movie: ' + data.error);
        }
    })
    .catch(error => alert('Error: ' + error));
}

    


// Function to send rent/return requests
function sendRentReturnRequest(email) {
    const csrftoken = getCookie('csrftoken');

    fetch('/rent/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken
        },
        body: JSON.stringify({ email: email })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to process rent/return request. Status: ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

{% block extra_js %}
<script src="{% static 'js/movie_management.js' %}"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.return-movie-button').forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault();  // Stop the link from causing a page navigation
                var movieId = this.getAttribute('data-movie-id');
                returnMovie(movieId);
            });
        });
    });
</script>
{% endblock %}