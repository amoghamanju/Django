// Static files directory: static/js/manage_movies.js

function fetchMovies() {
    fetch('/dbMovie/')
        .then(response => response.json())
        .then(data => {
            const movies = data.movies;
            const tableBody = document.getElementById('movie-list');
            tableBody.innerHTML = '';  // Clear existing rows
            movies.forEach(movie => {
                const row = `<tr>
                    <td>${movie.title}</td>
                    <td>${movie.in_stock}</td>
                    <td>${movie.checked_out}</td>
                    <td><button onclick="updateStock(${movie.id}, 'add')">+</button></td>
                    <td><button onclick="updateStock(${movie.id}, 'remove')">-</button></td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        });
}

function addNewMovie() {
    const title = document.getElementById('new-movie-title').value;
    fetch('/dbMovie/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken  // Ensure CSRF token is available globally
        },
        body: JSON.stringify({ action: 'new', title: title })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            document.getElementById('movie-message').innerText = data.error;
        } else {
            fetchMovies();  // Refresh the list
            document.getElementById('new-movie-title').value = '';  // Clear input
        }
    });
}

function updateStock(movieId, action) {
    console.log("Updating stock for movie:", movieId, "Action:", action);  // Debug: Log action attempt
    const url = "{% url 'update_movie_stock' %}";
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({ movieId: movieId, action: action })
    }).then(response => response.json())
      .then(data => {
          console.log("Server response:", data);  // Debug: Log server response
          if (data.success) {
              const stockCell = document.getElementById('stock-' + movieId);
              stockCell.innerText = data.new_stock;  // Ensure this matches what's sent back from the server
          } else {
              alert('Error updating stock: ' + data.error);
          }
      }).catch(error => {
          console.error('Error updating stock:', error);
      });
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

document.addEventListener('DOMContentLoaded', function () {
    console.log("DOM fully loaded and parsed");
    const addButtons = document.querySelectorAll('.add-stock');
    const removeButtons = document.querySelectorAll('.remove-stock');

    console.log("Add buttons found:", addButtons.length);
    console.log("Remove buttons found:", removeButtons.length);

    addButtons.forEach(button => {
        button.onclick = function() {
            console.log("Add button clicked for movie ID:", this.dataset.movieId);
            updateStock(this.dataset.movieId, 'add');
        };
    });

    removeButtons.forEach(button => {
        button.onclick = function() {
            console.log("Remove button clicked for movie ID:", this.dataset.movieId);
            updateStock(this.dataset.movieId, 'remove');
        };
    });
});
