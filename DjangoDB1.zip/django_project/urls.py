"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from tasks.views import (home, account_creation, manage_movies,
                         update_movie_stock, rent_return, ItemHandler,
                         checkout_movie, return_movie)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('account/', account_creation, name='account_creation'),
    path('movie/', manage_movies, name='manage_movies'),
    path('update_stock/', update_movie_stock, name='update_movie_stock'),
    path('rent/', rent_return,
         name='rent_return'),  # Correct path for rent_return
    path('checkout_movie/', checkout_movie, name='checkout_movie'),
    path('return_movie/', return_movie, name='return_movie'),
    path('item/', ItemHandler.as_view(), name='item_handler'),
]
