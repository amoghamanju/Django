from django.shortcuts import render
from django.http import JsonResponse
from .models import User, ZipCode

def main_page(request):
    return render(request, 'main_page.html')

def get_user_data(request):
    # Retrieve user from request or create a new one if it doesn't exist
    username = request.POST.get('username')
    user, created = User.objects.get_or_create(username=username)

    # Get zip codes associated with the user
    zip_codes = ZipCode.objects.filter(user=user)

    # Fetch weather data for each zip code (pseudo code)
    weather_data = []

    for zip_code in zip_codes:
        weather_data.append(fetch_weather_data(zip_code.code))

    return JsonResponse({'weather_data': weather_data})

def add_zip_code(request):
    # Retrieve user and zip code from request
    username = request.POST.get('username')
    zip_code = request.POST.get('zip_code')

    # Check if zip code is valid (pseudo code)
    if is_valid_zip_code(zip_code):
        user, created = User.objects.get_or_create(username=username)
        ZipCode.objects.get_or_create(user=user, code=zip_code)

    return JsonResponse({'status': 'success'})
