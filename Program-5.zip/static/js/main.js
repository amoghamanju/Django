$(document).ready(function() {
    $('#username').on('input', function() {
        // Fetch and display weather data when username changes
        var username = $(this).val();
        fetchUserData(username);
    });

    $('#add-zip-btn').click(function() {
        // Add zip code when button is clicked
        var username = $('#username').val();
        var zipCode = $('#zip-code').val();
        addZipCode(username, zipCode);
    });

    function fetchUserData(username) {
        $.post('/get_user_data/', {username: username}, function(data) {
            // Update user region with weather data
            $('#user-region').html(renderWeatherData(data.weather_data));
        });
    }

    function addZipCode(username, zipCode) {
        $.post('/add_zip_code/', {username: username, zip_code: zipCode}, function(data) {
            // Fetch and display updated user data
            fetchUserData(username);
        });
    }

    function renderWeatherData(weatherData) {
        // Render weather data as HTML table rows
        var rows = '';

        weatherData.forEach(function(item) {
            rows += '<tr><td>' + item.zipCode + '</td><td>' + item.temperature + '</td></tr>';
        });

        return '<table>' + rows + '</table>';
    }
});
