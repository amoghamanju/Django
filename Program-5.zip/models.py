from django.db import models


class User(models.Model):
  username = models.CharField(max_length=100)


class ZipCode(models.Model):
  user = models.ForeignKey(User, on_delete=models.CASCADE)
  code = models.CharField(max_length=10)
